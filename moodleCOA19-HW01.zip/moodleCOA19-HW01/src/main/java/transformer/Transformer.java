package transformer;

import java.math.BigDecimal;
import java.math.BigInteger;

public class Transformer {
    /**
     * Integer to binaryString
     *
     * @param numStr to be converted
     * @return result
     */
    static final int DATA_SIZE_LIMITATION=32;
    int elength=8;
    int slength=23;
    public String intToBinary(String numStr) {
        //TODO:
        StringBuilder sb=new StringBuilder("");
        int integer=Integer.parseInt(numStr);
        //先移位31位，做与操作，一直到移0位
        for(int i=DATA_SIZE_LIMITATION-1;i>=0;i--){
            sb.append(integer>>>i&1);
        }
        return sb.toString();

    }

    /**
     * BinaryString to Integer
     *
     * @param binStr : Binary string in 2's complement
     * @return :result
     */
    public String binaryToInt(String binStr) {
        StringBuilder sb=new StringBuilder("");
        StringBuilder sb2=new StringBuilder("");
        int sum=0;
//        if(binStr.charAt(0)=='1') {
//            sb.append("-");}
            //取反操作
//            for(int i=0;i<binStr.length();i++){
//                if(binStr.charAt(i)=='0')
//                    sb2.append('1');
//                else
//                    sb2.append('0');
//            }
//            //加1
//            sum=1;
//        }
//        else sb2.append(binStr);
//        //每一位乘以2对应的倍数
//        for(int j=DATA_SIZE_LIMITATION-1;j>=0;j--){
//            sum=sum+(sb2.charAt(j)-48)*Math.pow(2,DATA_SIZE_LIMITATION-1-j);
//        }
//        sb.append((int)sum);
            for(int i=31;i>0;i--){
                sum=sum+((binStr.charAt(i)-'0')<<(31-i));
                System.out.println(sum);
            }
            sum=sum-((binStr.charAt(0)-'0')<<31);
            System.out.println(sum);
            sb.append(sum);
        return sb.toString();

    }

    /**
     * Float true value to binaryString
     * @param floatStr : The string of the float true value
     * */
    public String floatToBinary(String floatStr) {
        StringBuilder sb=new StringBuilder("");
        //判断浮点数是正的还是负的，添加sb的符号位
        sb.append(floatStr.charAt(0)=='-'?'1':'0');
        if(floatStr.charAt(0)=='-'||floatStr.charAt(0)=='+')
            floatStr=floatStr.substring(1);
        //判断浮点数是否等于0.0
        if(Float.parseFloat(floatStr)==0.0){
            sb.append("0000000000000000000000000000000");
            return sb.toString();}
        //判断浮点数是否小于2的-126次方
        if(Double.parseDouble(floatStr)<Math.pow(2,-126)){
            sb.append("00000000");
            double d=Double.parseDouble(floatStr)*Math.pow(2,126);
            while (sb.length()!=32){
                d=d*2;
                int m=(int)d;
                sb.append(m);
                d=d-m;
            }
            return sb.toString();
        }
        //判断浮点数是否溢出
        if(Double.parseDouble(floatStr)>=Math.pow(2,129)) {
            if (sb.charAt(0) == '1') return "-Inf";
            else return "+Inf";
        }
        //把科学计数法的浮点数变成普通形式
        BigDecimal bd=new BigDecimal(floatStr);
        floatStr=bd.toPlainString();
        //@tmp 暂时储存整数和小数的二进制
        StringBuilder tmp=new StringBuilder("");
        //将浮点数分成整数和小数部分
        String[] str=floatStr.split("\\.");
        float k=Float.parseFloat("0."+str[1]);
        String integer=intToBinary(str[0]);
        tmp.append(integer);
        //把小数部分变成二进制
        while (k!=0.0){
            k=k*2;
            int l=(int)k;
            tmp.append(l);
            k=k-l;
            if(tmp.length()==64) break;
        }
        int index;
        //找到第一个1所在位置，用于确定小数点的位置
        for(index=0;index<64;index++){
            if(tmp.charAt(index)=='1')
                break;
        }
        String exponent=intToBinary(String.valueOf(DATA_SIZE_LIMITATION-1-index+127));
        sb.append(exponent.substring(DATA_SIZE_LIMITATION-elength));
        sb.append(tmp.substring(index+1));
        if(sb.length()>32) return sb.substring(0,32);
        for(int j=sb.length();j<DATA_SIZE_LIMITATION;j++)
            sb.append(0);
        return sb.toString();
    }

    /**
     * Binary code to its float true value
     * */
    public String binaryToFloat(String binStr) {
        //TODO:
        StringBuilder sb=new StringBuilder("");
        if(binStr.charAt(0)=='1') sb.append('-');
        double d=0.0;
        StringBuilder exponent=new StringBuilder(binStr.substring(1,9));
        StringBuilder fraction=new StringBuilder(binStr.substring(9));
        fraction.insert(0,"1");
        int e=Integer.parseInt(binaryToInt("000000000000000000000000"+exponent.toString()));
        //判断e是否等于0或255或其他
        if(e!=255&&e!=0)
            e=e-127;
        else if(e==0){
            if(!fraction.toString().substring(1).contains("1")){
                if(sb.toString().contains("-")) sb.append("0.0");
                else sb.append("0.0");
                return sb.toString();
            }
            else{
                e=e-126;
                fraction.replace(0,1,"0");
            };
        }
        else if(e==255){
            if(!fraction.toString().substring(1).contains("1")) {
                if (binStr.charAt(0) == '0') return "+Inf";
                if (binStr.charAt(0) == '1') return "-Inf";
            }
            else return null;
        };
        //对尾数乘以2的相应倍数
        for(int i=0;i<fraction.length();i++){
            if(fraction.charAt(i)=='1')
                d=d+Math.pow(2,e);
            e=e-1;
        }
        sb.append(d);
        return sb.toString();
    }

    /**
     * The decimal number to its NBCD code
     * */
    public String decimalToNBCD(String decimal) {

        String[] list={"0000","0001","0010","0011", "0100",
                "0101","0110","0111","1000","1001"};
        StringBuilder sb=new StringBuilder("");
        sb.append(decimal.charAt(0)=='-'?"1101":"1100");
        if(decimal.charAt(0)=='-'||decimal.charAt(0)=='+')
            decimal=decimal.substring(1);
        for(int j=0;j<decimal.length();j++){
            sb.append(list[decimal.charAt(j)-48]);
        }
        //在字符串中间补零
        while (sb.length()<32)
            sb.insert(4,0);
        return sb.toString();
    }

    /**
     * NBCD code to its decimal number
     * */
    public String NBCDToDecimal(String NBCDStr) {

        String[] list={"0000","0001","0010","0011", "0100",
                "0101","0110","0111","1000","1001"};
        int k=0,j;
        boolean flag=false;

        StringBuilder sb=new StringBuilder("");
        //判断正负，最后再加负号
        if(NBCDStr.substring(0,4).equals("1101")) flag=true;
        NBCDStr=NBCDStr.substring(4);
        //在list中找对应的数
        while (k!=28) {
            for (int i = 0; i < list.length; i++) {
                if (NBCDStr.substring(k, k + 4).equals(list[i])) {
                    sb.append(i);
                    break;
                }
            }
            k = k + 4;
        }
        //删除整数前面无效的0
        for( j=0;j<sb.length();j++) {
            if (sb.charAt(j) != '0')
                break;
        }
        sb.delete(0,j);
        if(flag) sb.insert(0,'-');
        //如果该数是0的话，添0
        if(sb.length()==0||sb.length()==1) sb.append('0');
        return sb.toString();
    }



}

